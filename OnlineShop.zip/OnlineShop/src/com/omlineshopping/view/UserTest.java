package com.omlineshopping.view;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.onlineshopping.Logic.InventoryManager;
import com.onlineshopping.model.Account;
import com.onlineshopping.model.Guest;
import com.onlineshopping.model.OrderLine;
import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductCategory;
import com.onlineshopping.model.ProductStatus;
import com.onlineshopping.model.Card;
import com.onlineshopping.model.RegisteredCustomer;
import com.onlineshopping.model.ShippingOption;

public class UserTest {

	public static void main(String[] args) {
		Card paymentCard=null;
		RegisteredCustomer customer= new RegisteredCustomer();
		Guest guest= new Guest();
		//guest.CreatAccount("Akrem", "Latiwesh", "akremly@hotmail.com", "akremly", "1234", "75 queens wharf", "75 queens warf");
	//	guest.CreatAccount("Akrem", "Latiwesh", "latiwesh.a@gmail.com", "admin", "1234", "75 queens wharf", "75 queens warf");
		InventoryManager invm=new InventoryManager();
		List<Product> products= invm.viewProducts();
		
		for (Product product : products) {
			System.out.println(product);
		}
		invm.addProduct("galaxy s5", "img/product-1.jpg", "img/product-thumb-1.jpg", ProductStatus.AVAILABLE,
				ProductCategory.PHONE, "bla bla bla", 12.2, "lg", 12);
		//Account account=customer.LogIn("akremly", "1234");
	//	System.out.println(account);
//		Date date = new Date();
//		customer.AddCard("345-567-456-345",date,account);
//	Set<Card> cards= account.getCards();
//	
//	for (Card card : cards) {
//		if(card.getCardNumber().equals("345-567-456-345")){
//			 paymentCard=card;
//			break;
//		}
//	}
//	
//	List<Product> products=customer.viewProducts();
//	
//
//	
//	customer.addOrderLine(products.get(0),1,account.getCart());
//	customer.addOrderLine(products.get(1),1,account.getCart());
//	
//	List<OrderLine> orderLines=account.getCart().getOrderLines();
//	System.out.println("number of orserlines: "+orderLines.size());
//	
//	for (OrderLine orderLine : orderLines) {
//		System.out.println(orderLine);
//	}
//	
//	customer.proccessOrder(orderLines, ShippingOption.TWODAYS, paymentCard, account);
//	
	}
}
