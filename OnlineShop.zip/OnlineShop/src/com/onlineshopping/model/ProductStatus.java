package com.onlineshopping.model;

public enum ProductStatus {
	AVAILABLE,Recalled

}
