package com.onlineshopping.model;
import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import org.eclipse.jdt.internal.compiler.ast.FalseLiteral;

@Entity
@Table(name="TBL_Product")
public class Product implements Serializable {
	
    @Id
    @Column(name="product_id")
 	@SequenceGenerator(name="product_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="product_seq")
	private int id;
    
    @Column(name="product_name",nullable=false)
	private String name;
    @Column(nullable=false, length=60)
    private String mainImage;
    @Column(nullable=false, length=60)
    private String thumbImage;
    @Column(nullable=false)
    @Enumerated(EnumType.STRING)
	private ProductStatus status;
    @Column(nullable=false)
    @Enumerated(EnumType.STRING)
    private ProductCategory category;
    @Column(nullable=false)
	private String description;
    @Column(nullable=false)
	private double price;
    @Column(nullable=false)
	private String provider;
    @Column(nullable=false)
	private int quantity;
    @OneToMany(mappedBy="product", fetch=FetchType.LAZY)
    private List<OrderLine> orderLines;
    @OneToMany(mappedBy="product", fetch=FetchType.LAZY)
    private List<OrderDetails> orderDetails;
	
    
	public Product() {
		super();

	}

	public Product( String name,String mainImage, String thumbImage, ProductStatus status, ProductCategory category, String description, double price, String provider, int quantity) {
		super();
		
		this.name = name;
		this.mainImage=mainImage;
		this.thumbImage=thumbImage;
		this.status = status;
		this.category=category;
		this.description = description;
		this.price = price;
		this.provider = provider;
		this.quantity=quantity;
		this.orderLines=orderLines;
		this.orderDetails=orderDetails;
	}

	
	public Product(int id, String name, String mainImage, String thumbImage, ProductStatus status,
			ProductCategory category, String description, double price, String provider, int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.mainImage = mainImage;
		this.thumbImage = thumbImage;
		this.status = status;
		this.category = category;
		this.description = description;
		this.price = price;
		this.provider = provider;
		this.quantity = quantity;
		this.orderLines = orderLines;
		this.orderDetails = orderDetails;
	}

	public ProductCategory getCategory() {
		return category;
	}

	public void setCategory(ProductCategory category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ProductStatus getStatus() {
		return status;
	}

	public void setStatus(ProductStatus status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

	public String getMainImage() {
		return mainImage;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public String getThumbImage() {
		return thumbImage;
	}

	public void setThumbImage(String thumbImage) {
		this.thumbImage = thumbImage;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((provider == null) ? 0 : provider.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (provider == null) {
			if (other.provider != null)
				return false;
		} else if (!provider.equals(other.provider))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Product [Id=" + id + ", name=" + name + ", status=" + status + ", category=" + category
				+ ", description=" + description + ", price=" + price + ", provider=" + provider + ", quantity="
				+ quantity + "]";
	}
	
	
	

}
