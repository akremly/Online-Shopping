package com.onlineshopping.model;

public enum ProductCategory {

		PHONE,ACCESSORIES
}
