package com.onlineshopping.model;

import java.util.Date;
import java.util.List;

import com.onlineshopping.Logic.AccountManager;
import com.onlineshopping.Logic.InventoryManager;
import com.onlineshopping.Logic.InventoryViewer;
import com.onlineshopping.Logic.LoginController;
import com.onlineshopping.Logic.OrderLineDao;
import com.onlineshopping.Logic.OrderLineManager;
import com.onlineshopping.Logic.OrderManager;

public class RegisteredCustomer extends User implements InventoryViewer{

	private LoginController loginController;
	private Account account;
	private InventoryViewer invViewer;
	private AccountManager am;
	private OrderLineManager orderLineManager;
	private OrderManager orderManager;
	private boolean LogedIn=true;
	private int Cart;
	
	

	public RegisteredCustomer() {
		super();
		loginController= new LoginController();
		invViewer= new InventoryManager();
		am=new AccountManager();
		orderLineManager= new OrderLineManager();
		orderManager= new OrderManager();
		
	}


	



	public List<Account> LogIn( String username, String password){
		List<Account> account= this.loginController.LogIn(username, password );
		 am.createCart(account.get(0));
		return	account;
	}
	
	public void LogOut() {
		if(LogedIn)
		if(this.loginController.LogOut())
			account=null;
		else
	   		 System.out.println("you have to Log-in first");
	}
	
	
	
	public void addProductToCart(Product p, int q) {
		
		
		
	}

     public void deleteProductFromCart(OrderLine orderLine) {
    	
    		this.account.getCart().deleteOrderLine(orderLine);
    	 
    	}
     
     public void deleteCard(Card card){
    	
    	 this.am.deleteCard(card);
    	
     }
     
     public void AddCard(String cardNumber, Date ExpiryDate, Account account){
    	
    	this.am.addCard(cardNumber,ExpiryDate,account);
    	
     }
     
     






	@Override
	public List<Product> viewProducts() {
		
		return this.invViewer.viewProducts();
	}






	@Override
	public List<Product> searchProductsByCategory(ProductCategory category) {
	
		return null;
	}






	@Override
	public void closeConnection() {
		this.invViewer.closeConnection();
		
	}






	public void addOrderLine(Product product, int quantity, Cart cart2) {
		orderLineManager.addOrderLine(product,quantity, cart2);
		
	}

	public void deleteOrderLine(OrderLine orderLine){
		orderLineManager.removeOrderLine(orderLine);
	}
	

	public void proccessOrder(List<OrderLine> orderLines, ShippingOption shippingOption, Card card, Account account){
		this.orderManager.proccessOrder(orderLines, shippingOption, card, account);
	}
	

	
	
}
