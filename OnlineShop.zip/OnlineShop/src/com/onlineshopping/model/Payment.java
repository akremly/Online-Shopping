package com.onlineshopping.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TBL_PAYMENT")
public class Payment {
	@Id
	@Column(name="PAYMENT_ID")
	@SequenceGenerator(name="payment_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="payment_seq")
	private int id;
	@OneToOne
	private Card card;
	@Column(name="TOTAL")
	private double totalAmount;
	@OneToOne
	private Order order;

public Payment() {
	super();
	
}




public Payment(Card card, double totalAmount, Order order) {
	super();
	this.card = card;
	this.totalAmount = totalAmount;
	this.order = order;
}




public Card getCard() {
	return card;
}

public void setCard(Card card) {
	this.card = card;
}

public double getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(double totalAmount) {
	this.totalAmount = totalAmount;
}



}
