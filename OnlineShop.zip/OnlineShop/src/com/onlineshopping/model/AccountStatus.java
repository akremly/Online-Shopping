package com.onlineshopping.model;

public enum AccountStatus {

	Active, Closed
	
}
