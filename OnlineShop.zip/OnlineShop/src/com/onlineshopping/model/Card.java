package com.onlineshopping.model;

import java.util.Date;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="TBL_CARD")
public class Card {

	@Id
	@Column(name="CARD_ID")
 	@SequenceGenerator(name="card_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="card_seq")
	private int Id;
	@Column(name="CARD_NUMBER")
	private String CardNumber;
	@Column(name="EXPIRY_DATE")
	@Temporal(TemporalType.DATE)
	private Date expiryDate;
	@ManyToOne(fetch=FetchType.LAZY)
	private Account account;
	@OneToOne(mappedBy="card")
	private Payment payment;
	
	
	public Card() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Card(String cardNumber, Date expiryDate, Account account) {
		super();
		CardNumber = cardNumber;
		this.expiryDate = expiryDate;
		this.account = account;
	}

	public String getCardNumber() {
		return CardNumber;
	}
	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((CardNumber == null) ? 0 : CardNumber.hashCode());
		result = prime * result + ((expiryDate == null) ? 0 : expiryDate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Card other = (Card) obj;
		if (CardNumber == null) {
			if (other.CardNumber != null)
				return false;
		} else if (!CardNumber.equals(other.CardNumber))
			return false;
		if (expiryDate == null) {
			if (other.expiryDate != null)
				return false;
		} else if (!expiryDate.equals(other.expiryDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Card [Id=" + Id + ", CardNumber=" + CardNumber + ", expiryDate=" + expiryDate + "]";
	}
	
	
}
