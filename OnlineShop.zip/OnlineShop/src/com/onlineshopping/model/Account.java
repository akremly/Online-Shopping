package com.onlineshopping.model;

import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.onlineshopping.Logic.AccountManager;
@Entity
@Table(name="TBL_ACCOUNT")
public class Account {
	@Id
	@Column(name="ACCOUNT_ID")
 	@SequenceGenerator(name="account_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="account_seq")
    private int Id;
	@Column(name="FIRST_NAME", nullable=false, length=50)
	private String firstName;
	@Column(name="LAST_NAME", nullable=false, length=50)
	private String lastName;
	@Column(nullable=false, length=40)
    private String username;
	@Column(nullable=false, length=50)
    private String Password;
	@Column(nullable=false, length=50)
    private String email;
	@Column(name="START_DATE", nullable=false)
	@Temporal(TemporalType.DATE)
    private Date startDate;
	@Column(name="ACCOUNT_STATUS", nullable=false)
	@Enumerated(EnumType.STRING)
    private AccountStatus status;
	@Column(name="SHIPPING_ADDRESS")
    private String shippingAddress;
	@Column(name="HOME_ADDRESS")
    private String homeAddress;
	@OneToMany(mappedBy="account", fetch=FetchType.EAGER)
    private Set<Card> cards;
	@OneToMany(mappedBy="account", fetch=FetchType.EAGER)
    private List<Order> orders;
	@OneToOne(mappedBy="account", fetch=FetchType.EAGER)
	private Cart cart;



public Account() {
		super();

	}



public Account(String firstName, String lastName, String username, String password, String email, Date startDate,
		AccountStatus status, String shippingAddress, String homeAddress) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.username = username;
	Password = password;
	this.email = email;
	this.startDate = startDate;
	this.status = status;
	this.shippingAddress = shippingAddress;
	this.homeAddress = homeAddress;
	this.cart = cart;
	this.orders=orders;
	this.cards=cards;
}



public int getId() {
	return Id;
}

public void setId(int id) {
	Id = id;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return Password;
}

public void setPassword(String password) {
	Password = password;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public Date getStartDate() {
	return startDate;
}

public void setStartDate(Date startDate) {
	this.startDate = startDate;
}

public AccountStatus getStatus() {
	return status;
}

public void setStatus(AccountStatus status) {
	this.status = status;
}

public String getShippingAddress() {
	return shippingAddress;
}

public void setShippingAddress(String shippingAddress) {
	this.shippingAddress = shippingAddress;
}

public String getHomeAddress() {
	return homeAddress;
}

public void setHomeAddress(String homeAddress) {
	this.homeAddress = homeAddress;
}

public Cart getCart() {
	return cart;
}



public Set<Card> getCards() {
	return cards;
}


public List<Order> getOrders() {
	return orders;
}




@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + Id;
	result = prime * result + ((Password == null) ? 0 : Password.hashCode());
	result = prime * result + ((email == null) ? 0 : email.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((homeAddress == null) ? 0 : homeAddress.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + ((shippingAddress == null) ? 0 : shippingAddress.hashCode());
	result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
	result = prime * result + ((status == null) ? 0 : status.hashCode());
	result = prime * result + ((username == null) ? 0 : username.hashCode());
	return result;
}



@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Account other = (Account) obj;
	if (Id != other.Id)
		return false;
	if (Password == null) {
		if (other.Password != null)
			return false;
	} else if (!Password.equals(other.Password))
		return false;
	if (email == null) {
		if (other.email != null)
			return false;
	} else if (!email.equals(other.email))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (homeAddress == null) {
		if (other.homeAddress != null)
			return false;
	} else if (!homeAddress.equals(other.homeAddress))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (shippingAddress == null) {
		if (other.shippingAddress != null)
			return false;
	} else if (!shippingAddress.equals(other.shippingAddress))
		return false;
	if (startDate == null) {
		if (other.startDate != null)
			return false;
	} else if (!startDate.equals(other.startDate))
		return false;
	if (status != other.status)
		return false;
	if (username == null) {
		if (other.username != null)
			return false;
	} else if (!username.equals(other.username))
		return false;
	return true;
}



@Override
public String toString() {
	return "Account [Id=" + Id + ", firstName=" + firstName + ", lastName=" + lastName + ", username=" + username
			+ ", Password=" + Password + ", email=" + email + ", startDate=" + startDate + ", status=" + status
			+ ", shippingAddress=" + shippingAddress + ", homeAddress=" + homeAddress + "]";
}



}
