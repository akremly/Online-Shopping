package com.onlineshopping.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="TBL_ORDER")
public class Order {
 
	@Id
	@Column(name="ORDER_ID")
 	@SequenceGenerator(name="order_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="order_seq")
	private int Id;
	@Column(name="ORDER_STATUS")
	@Enumerated(EnumType.STRING)
	private OrderStatus status;
	@Column(name="SHIPPING_DATE")
	private Date shippingDate;
	@Column(name="SHIPPING_ADDRESS")
	private String shippingAddress;
	@Column(name="SHIPPING_OPTION")
	@Enumerated(EnumType.STRING)
	private ShippingOption shippingOption;
	@OneToOne(mappedBy="order")
    private Payment payment;

    @ManyToOne
    private Account account;
    @OneToMany(mappedBy="order", fetch=FetchType.LAZY)
    private List<OrderDetails> orderDetails;
    
    
	
	public Order() {
		super();
		
	}
	
	public Order(OrderStatus status, Date shippingDate, String shippingAddress, ShippingOption shippingOption,
			Account account) {
		super();
		this.status = status;
		this.shippingDate = shippingDate;
		this.shippingAddress = shippingAddress;
		this.shippingOption = shippingOption;
		this.account = account;
	}

	public int getId() {
		return Id;
	}
	
	public OrderStatus getStatus() {
		return status;
	}
	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	public Date getShippingDate() {
		return shippingDate;
	}
	public void setShippingDate(Date shippingDate) {
		this.shippingDate = shippingDate;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	
	
	
	public List<OrderDetails> getOrderDetails() {
		return orderDetails;
	}
	public ShippingOption getShippingOption() {
		return shippingOption;
	}
	public void setShippingOption(ShippingOption shippingOption) {
		this.shippingOption = shippingOption;
	}
	public Payment getPayment() {
		return payment;
	}
	
	public void proccessOrder(List<OrderLine> orderLines){
		
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Id;
		result = prime * result + ((shippingAddress == null) ? 0 : shippingAddress.hashCode());
		result = prime * result + ((shippingDate == null) ? 0 : shippingDate.hashCode());
		result = prime * result + ((shippingOption == null) ? 0 : shippingOption.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (Id != other.Id)
			return false;
		if (shippingAddress == null) {
			if (other.shippingAddress != null)
				return false;
		} else if (!shippingAddress.equals(other.shippingAddress))
			return false;
		if (shippingDate == null) {
			if (other.shippingDate != null)
				return false;
		} else if (!shippingDate.equals(other.shippingDate))
			return false;
		if (shippingOption != other.shippingOption)
			return false;
		if (status != other.status)
			return false;
		return true;
	}
    
	
	
    
    
    

	
}
