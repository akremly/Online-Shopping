package com.onlineshopping.model;

public enum ShippingOption {
STANDARD, TWODAYS
}
