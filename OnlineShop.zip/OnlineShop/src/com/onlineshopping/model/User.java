package com.onlineshopping.model;

public class User {

}
