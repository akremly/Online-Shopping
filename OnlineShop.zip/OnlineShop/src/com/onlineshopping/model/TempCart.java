package com.onlineshopping.model;

import java.util.HashMap;
import java.util.List;



public class TempCart {
	
	
	private HashMap<Product, Integer> orderLines;
	private double totalAmmount=0.0;

	

	public TempCart() {
		super();
		orderLines=new HashMap<>();
	}

	public HashMap<Product, Integer> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(HashMap<Product, Integer> orderLines) {
		this.orderLines = orderLines;
	}
	
	public void addOrderLine(Product product, Integer quantity){
	if(orderLines.put(product, quantity) == null)
		totalAmmount+=product.getPrice();
	
		}
	public void deleteOrderLine(Product product){
		totalAmmount-=product.getPrice();
		this.orderLines.remove(product);
	}
	public double getTotalAmmount() {
		return Math.round(totalAmmount);
	}

	

	

}
