package com.onlineshopping.model;

public enum OrderStatus {
NEW,SHIPPED,DELIVERED,CLOSED
}
