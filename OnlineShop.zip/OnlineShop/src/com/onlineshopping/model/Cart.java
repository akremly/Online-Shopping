package com.onlineshopping.model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TBL_CART")
public class Cart {

	@Id
	@Column(name="CART_ID")
 	@SequenceGenerator(name="cart_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="cart_seq")
	private int Id;
	@OneToMany(mappedBy="cart", fetch=FetchType.LAZY)
	private List<OrderLine> orderLines;
	@OneToOne
	private Account account;
	
	public Cart() {
		super();
		this.orderLines =orderLines;
	}

	public Cart(Account account) {
		super();
		this.account = account;
	}

	public void addOrderLine(Product product, int quantity) {

		if(this.CheckProductAvailability(product, quantity));
			
		
	}

	public boolean CheckProductAvailability(Product mockProduct, int Quantity) {
	
	return false;
	}
	
	public void deleteOrderLine(OrderLine orderLine){
		orderLines.remove(orderLine);
	}

	public List<OrderLine> getOrderLines() {
		return orderLines;
	}
	
	public int getNumberOfItemsInCart(){
		return orderLines.size();
	}

	@Override
	public String toString() {
		return "Cart [Id=" + Id + ", account=" + account + "]";
	}

	

}
