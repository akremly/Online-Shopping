package com.onlineshopping.model;

import com.onlineshopping.Logic.AccountManager;
import com.onlineshopping.Logic.LoginController;

public class Guest extends User {

	private AccountManager accountManager= null;
	public Guest() {
		super();
		accountManager=new AccountManager();
	}
	
	public void CreatAccount(String firstName,String lastName,String email,String userName,String password,String shippingAddress,String homeAddress){
		if(accountManager.CreatAccount(firstName, lastName, email, userName, password, shippingAddress, homeAddress))
			System.out.println("your account was created");
		else
			System.out.println("Either username or passowrd is wrong");
	}

	
	
}
