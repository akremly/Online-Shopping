package com.onlineshopping.servlets;

import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import com.onlineshopping.Logic.InventoryManager;
import com.onlineshopping.Logic.OrderLineManager;
import com.onlineshopping.model.Account;
import com.onlineshopping.model.Cart;
import com.onlineshopping.model.OrderLine;
import com.onlineshopping.model.Product;
import com.onlineshopping.model.TempCart;

/**
 * Servlet implementation class CartServlet
 */

public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private TempCart cart;
    private Boolean oldCartRetrieved=true;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
       cart= new TempCart();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(oldCartRetrieved){
			Account account=(Account) request.getSession().getAttribute("account");
			for (OrderLine orderLine : account.getCart().getOrderLines()) {
				cart.addOrderLine(orderLine.getProduct(), orderLine.getQuantity());
			  }	
			oldCartRetrieved=false;
			}
    	Account account=(Account) request.getSession().getAttribute("account");
		request.setAttribute("orderlines", cart.getOrderLines());
		request.getSession().setAttribute("cart", cart);
		RequestDispatcher rd= request.getRequestDispatcher("cart.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InventoryManager inm= new InventoryManager();
		String quantity=request.getParameter("quantity");
		String id=request.getParameter("myProductId");
		Product product= inm.findProductById(id);
		
		if(!oldCartRetrieved){
		Account account=(Account) request.getSession().getAttribute("account");
		for (OrderLine orderLine : account.getCart().getOrderLines()) {
			cart.addOrderLine(orderLine.getProduct(), orderLine.getQuantity());
		  }	
		oldCartRetrieved=true;
		}
		
		cart.addOrderLine(product, Integer.parseInt(quantity));
		request.getSession().setAttribute("cart", cart);
		RequestDispatcher rd= request.getRequestDispatcher("cart.jsp");
		rd.forward(request, response);

	}

}
