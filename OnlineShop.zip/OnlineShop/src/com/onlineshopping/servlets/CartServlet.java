package com.onlineshopping.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import com.onlineshopping.Logic.InventoryManager;
import com.onlineshopping.Logic.OrderLineManager;
import com.onlineshopping.model.Account;
import com.onlineshopping.model.OrderLine;
import com.onlineshopping.model.Product;

/**
 * Servlet implementation class CartServlet
 */

public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Account account=(Account) request.getSession().getAttribute("account");
		request.setAttribute("orderlines", account.getCart().getOrderLines());
		RequestDispatcher rd= request.getRequestDispatcher("cart.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InventoryManager inm= new InventoryManager();
		OrderLineManager olm= new OrderLineManager();
		String quantity=request.getParameter("quantity");
		String id=request.getParameter("myProductId");
		Product product= inm.findProductById(id);
		Account account=(Account) request.getSession().getAttribute("account");
		
		System.out.println(account);
		System.out.println(product);
		olm.addOrderLine(product, Integer.parseInt(quantity), account.getCart());
		request.getSession().removeAttribute("account");
		request.getSession().setAttribute("account", account);
		request.setAttribute("singleProduct", product);
		RequestDispatcher rd= request.getRequestDispatcher("single-product.jsp");
		rd.forward(request, response);
		
	
	}

}
