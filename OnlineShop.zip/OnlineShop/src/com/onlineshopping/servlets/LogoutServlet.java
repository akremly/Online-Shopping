package com.onlineshopping.servlets;

import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineshopping.Logic.OrderLineManager;
import com.onlineshopping.model.Account;
import com.onlineshopping.model.Cart;
import com.onlineshopping.model.Product;
import com.onlineshopping.model.TempCart;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private OrderLineManager olm;  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		olm= new OrderLineManager();
		HttpSession session=request.getSession();
		request.setAttribute("products", session.getAttribute("products"));
		Account account= (Account) request.getSession().getAttribute("account");
		TempCart tempCart=(TempCart) request.getSession().getAttribute("cart");
		for(Map.Entry<Product, Integer> orderline: tempCart.getOrderLines().entrySet()){
		olm.addOrderLine(orderline.getKey(), orderline.getValue(), account.getCart());
		}
		session.setAttribute("account", null);
		session.setAttribute("cart", null);
		session.removeAttribute("account");
		session.removeAttribute("cart");
		session.invalidate();
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
	}

}
