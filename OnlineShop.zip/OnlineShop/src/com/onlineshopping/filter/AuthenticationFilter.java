package com.onlineshopping.filter;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
//@WebFilter("/AuthenticationFilter")
public class AuthenticationFilter implements Filter {

	ArrayList<String> excludedUrls= new ArrayList<>();
    /**
     * Default constructor. 
     */
    public AuthenticationFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpreq= (HttpServletRequest) request;
		HttpSession session= httpreq.getSession(false);
		
		if((session == null || session.getAttribute("account")==null) && !excludedUrls.contains(httpreq.getServletPath()) && !httpreq.getServletPath().matches(".*(css|jpg|png|gif|js)")){
			RequestDispatcher rd= request.getRequestDispatcher("/home");
			rd.forward(request, response);
		}else{
			chain.doFilter(request, response);	
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		excludedUrls.add("/home");
		excludedUrls.add("/handlelogin");
		excludedUrls.add("/index.jsp");
		excludedUrls.add("/searchbycategory");
		excludedUrls.add("/single");
		excludedUrls.add("/checkout.jsp");
		
		
		
	
		
		
	}

}
