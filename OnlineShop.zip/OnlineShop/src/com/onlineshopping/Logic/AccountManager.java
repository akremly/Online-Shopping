package com.onlineshopping.Logic;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.onlineshopping.model.Account;
import com.onlineshopping.model.AccountStatus;
import com.onlineshopping.model.Card;
import com.onlineshopping.model.Cart;
import com.onlineshopping.model.Product;

public class AccountManager{

	private  EntityManager em=null;
	private  EntityTransaction transaction=null;

	public boolean CreatAccount(String firstName, String lastName, String email, String userName, String password, String shippingAddress, String homeAddress) {
		em=AccountDao.getInstance().getConnection();
		Query query=em.createQuery("SELECT a FROM Account a WHERE username=:uname ", Account.class);
		query.setParameter("uname", userName);
		if(query.getResultList().size() != 0)
			return false;
	  

	     Date date = new Date();
		 Account account= new Account(firstName, lastName, userName, password, email,date, AccountStatus.Active, shippingAddress, homeAddress);
		transaction=em.getTransaction();
		transaction.begin();
		em.persist(account);
		transaction.commit();
		em.clear();
		return true;
	}

	public  void addCard(String cardNumber, Date expiryDate, Account account) {
		Card card = new Card(cardNumber, expiryDate, account);
		em=AccountDao.getInstance().getConnection();
		transaction=em.getTransaction();
		transaction.begin();
		em.persist(card);
		transaction.commit();
		
	}

	public  void deleteCard(Card card) {
	
	em=AccountDao.getInstance().getConnection();
	Query query=em.createQuery("SELECT c FROM Card c WHERE c.CardNumber=:cnum",Card.class);
	query.setParameter("cnum", card.getCardNumber());
	Card exCard=(Card)query.getSingleResult();
	transaction=em.getTransaction();
	transaction.begin();
	em.remove(exCard);
	transaction.commit();
		
	}

	public void createCart(Account account) {
		if(account.getCart() == null){
		em=AccountDao.getInstance().getConnection();
	
		Cart cart= new Cart(account);
		transaction=em.getTransaction();
		transaction.begin();
		em.persist(cart);
		transaction.commit();
		}
		
	}

	
	
	
	
	

}
