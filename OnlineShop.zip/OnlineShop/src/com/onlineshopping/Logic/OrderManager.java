package com.onlineshopping.Logic;


import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.onlineshopping.model.Account;
import com.onlineshopping.model.Card;
import com.onlineshopping.model.Order;
import com.onlineshopping.model.OrderDetails;
import com.onlineshopping.model.OrderLine;
import com.onlineshopping.model.OrderStatus;
import com.onlineshopping.model.Payment;
import com.onlineshopping.model.ShippingOption;

public class OrderManager {
	private EntityManager em=null;
	private EntityTransaction transaction=null;
	private double total=0.0;
	private OrderLineManager orderLineManager;
	private InventoryManager inventoryManager;
	
	
	public OrderManager() {
		super();
		orderLineManager= new OrderLineManager();
		inventoryManager=new InventoryManager();
	}


	public void proccessOrder(List<OrderLine> orderLines,ShippingOption shippingOption,Card card, Account account){
		
		em=OrdersDAO.getInstance().getConnection();
		transaction=em.getTransaction();
		Order order=addOrder(shippingOption,account);
		for (OrderLine orderLine : orderLines) {
		OrderDetails orderDetail= new OrderDetails(orderLine.getProduct(), orderLine.getQuantity(), order);
		addOrderDetail(orderDetail);
		total+=orderLine.getProduct().getPrice();
		orderLineManager.removeOrderLine(orderLine.getProduct());
		orderLine.getProduct().setQuantity(orderLine.getProduct().getQuantity()-orderLine.getQuantity());
		inventoryManager.updateProduct(orderLine.getProduct());
		}
		Payment payment= new Payment(card, total, order);
		addPayment(payment);
	}


	private void addPayment(Payment payment) {
		
		transaction.begin();
		em.persist(payment);
		transaction.commit();
		
	}


	private void addOrderDetail(OrderDetails orderDetail) {
		transaction.begin();
		em.persist(orderDetail);
		transaction.commit();
	}


	private Order addOrder(ShippingOption shippingOption, Account account) {
	Date date= new Date();
		Order order= new Order(OrderStatus.NEW,date , account.getShippingAddress(), shippingOption, account);
		transaction.begin();
		em.persist(order);
		transaction.commit();
		return order;
	}
	
	
	
	
	

}
