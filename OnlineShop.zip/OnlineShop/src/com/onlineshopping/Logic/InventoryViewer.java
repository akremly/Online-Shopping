package com.onlineshopping.Logic;
import java.util.List;

import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductCategory;;
public interface InventoryViewer {

	
	List<Product> viewProducts();
	List<Product> searchProductsByCategory(ProductCategory category);
	 void closeConnection();
}
