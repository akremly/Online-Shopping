package com.onlineshopping.Logic;

import java.sql.Connection;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class InventoryDAO {

	private static InventoryDAO dao;
	private EntityManagerFactory emf=null;
	private EntityManager em=null;

	public InventoryDAO() {
		inti();

	}

	private void inti() {
		emf=Persistence.createEntityManagerFactory("OnlineShop");
		em=emf.createEntityManager();
		
	}
	
	public static InventoryDAO getInstance() {
		if(dao==null)
			dao= new InventoryDAO();
		return dao;
		
	}
	
	public EntityManager getConnection() {
		
		return em;
	}
	
}
