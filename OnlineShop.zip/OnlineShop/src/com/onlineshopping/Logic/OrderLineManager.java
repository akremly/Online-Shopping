package com.onlineshopping.Logic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.onlineshopping.model.Cart;
import com.onlineshopping.model.Order;
import com.onlineshopping.model.OrderLine;
import com.onlineshopping.model.Product;

public class OrderLineManager {

	private  EntityManager em=null;
	private  EntityTransaction transaction=null;
	
	public void addOrderLine(Product product, int quantity, Cart cart) {
		em=OrderLineDao.getInstance().getConnection();
		OrderLine orderLine= new OrderLine(product, cart, quantity);
		transaction=em.getTransaction();
		transaction.begin();
		em.persist(orderLine);
		transaction.commit();
		
		
	}
	
	public void removeOrderLine(OrderLine orderLine){
		em=OrderLineDao.getInstance().getConnection();	
		OrderLine exOrderLine=em.find(OrderLine.class, orderLine.getId());
		transaction=em.getTransaction();
		transaction.begin();
		em.remove(exOrderLine);
		transaction.commit();
	}
	
	public void updateOrderLine(OrderLine orderLine){
		
		em=OrderLineDao.getInstance().getConnection();	
		OrderLine exOrderLine=em.find(OrderLine.class, orderLine.getId());
		transaction=em.getTransaction();
		transaction.begin();
		exOrderLine.setQuantity(orderLine.getQuantity());
		transaction.commit();
	}
	
	
	public List<Order> getAllNewOrders(){
		
		em=em=OrderLineDao.getInstance().getConnection();	
		Query query=em.createQuery("SELECT O FROM Order o WHERE o.orderStatus=:ostatus", Order.class);
		query.setParameter("ostatus", "NEW");
		
		return query.getResultList();
		
	}
}
