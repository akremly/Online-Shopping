package com.onlineshopping.Logic;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class OrdersManager {
	private EntityManager em=null;
	private EntityTransaction transaction=null;
	
	public OrdersManager() {
		super();
		
	}

}
