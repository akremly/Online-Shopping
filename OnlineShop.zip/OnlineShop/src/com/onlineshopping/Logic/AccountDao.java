package com.onlineshopping.Logic;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AccountDao {
	private static AccountDao dao;
	private EntityManagerFactory emf=null;
	private EntityManager em=null;

	public AccountDao() {
		inti();

	}

	private void inti() {
		emf=Persistence.createEntityManagerFactory("OnlineShop");
		em=emf.createEntityManager();
		
	}
	
	public static AccountDao getInstance() {
		if(dao==null)
			dao= new AccountDao();
		return dao;
		
	}
	
	public EntityManager getConnection() {
		return em;
	}
	
}
