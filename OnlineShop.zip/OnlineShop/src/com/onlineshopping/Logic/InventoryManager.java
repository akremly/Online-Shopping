package com.onlineshopping.Logic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductCategory;
import com.onlineshopping.model.ProductStatus;

public class InventoryManager implements InventoryViewer, InventoryUpdater{

	private EntityManager em=null;
	private EntityTransaction transaction=null;
	
	public InventoryManager() {
		super();
		
	}

	@Override
	public synchronized List<Product> viewProducts() {
		em=InventoryDAO.getInstance().getConnection();
	  Query query= em.createQuery("SELECT  p FROM Product p",Product.class);
	  List<Product> products=query.getResultList();
	  em.clear();
		return products;
		
	}

	@Override
	public synchronized List<Product> searchProductsByCategory(ProductCategory category) {
		em=InventoryDAO.getInstance().getConnection();
		  Query query=em.createQuery("SELECT  p FROM Product p WHERE p.category=:pcategory ",Product.class);
		  query.setParameter("pcategory", category);
		  em.clear();
		return query.getResultList();
	}

	@Override
	public synchronized void updateProduct(Product product) {
		em=InventoryDAO.getInstance().getConnection();
		Query query=em.createQuery("SELECT  p FROM Product p WHERE p.name=:pname ",Product.class);
		  query.setParameter("pname", product.getName());
		  Product Exproduct=(Product)query.getSingleResult();
			transaction=em.getTransaction();
		  transaction.begin();
		  Exproduct.setPrice(product.getPrice());
		  Exproduct.setDescription(product.getDescription());
		  Exproduct.setQuantity(product.getQuantity());
		  Exproduct.setStatus(product.getStatus());
		  Exproduct.setName(product.getName());
		  Exproduct.setProvider(product.getProvider());
		  transaction.commit();
		  em.clear();
	
		
	}

	@Override
	public synchronized void addProduct(String name,String mainImage, String thumbImage,ProductStatus status,ProductCategory category ,String description, double price, String provider, int quantity) {
		Product product= new Product(name,mainImage, thumbImage,status,category, description, price, provider, quantity);
		em=InventoryDAO.getInstance().getConnection();
		transaction=em.getTransaction();
		transaction.begin();
		em.persist(product);
		transaction.commit();
		  em.clear();
	}

	@Override
	public synchronized void deleteProduct(String id) {
	Product product=this.findProductById(id);
	em=InventoryDAO.getInstance().getConnection();
	transaction=em.getTransaction();
	transaction.begin();
	em.remove(product);
	transaction.commit();

	}

	@Override
	public synchronized Product findProductById(String id) {
		em=InventoryDAO.getInstance().getConnection();
		Product product=em.find(Product.class, (int) Integer.parseInt(id));
		
		return product;
	}
	
	public void closeConnection(){
		this.em.clear();
	}

	@Override
	public List<Product> viewTopProducts() {
		em=InventoryDAO.getInstance().getConnection();
		  Query query= em.createQuery("SELECT p FROM Product p",Product.class);
		  List<Product> products=query.setMaxResults(10).getResultList();
		  em.clear();
			return products;	}

}
