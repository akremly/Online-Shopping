package com.onlineshopping.Logic;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.onlineshopping.model.Account;

public class LoginController {

	private EntityManager em=null;
	
	
	
	public List<Account> LogIn(String username, String password) {
		em=InventoryDAO.getInstance().getConnection();
		List<Account> account= new ArrayList<Account>();
		Query query=em.createQuery("SELECT a FROM Account a WHERE username=:uname AND Password=:pw ", Account.class);
		query.setParameter("uname", username);
		query.setParameter("pw", password);
		account = (List<Account>)query.getResultList();
		return account;
	}

	public boolean LogOut() {
	 
		
		return false;
	}

}
