package com.onlineshopping.Logic;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OrdersDAO {
	private static OrdersDAO dao;
	private EntityManagerFactory emf=null;
	private EntityManager em=null;

	public OrdersDAO() {
		inti();

	}

	private void inti() {
		emf=Persistence.createEntityManagerFactory("OnlineShop");
		em=emf.createEntityManager();
		
	}
	
	public static OrdersDAO getInstance() {
		if(dao==null)
			dao= new OrdersDAO();
		return dao;
		
	}
	
	public EntityManager getConnection() {
		return em;
	}
	
}
