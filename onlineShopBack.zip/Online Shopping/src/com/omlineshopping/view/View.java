package com.omlineshopping.view;

import java.util.ArrayList;
import java.util.List;

import com.onlineshopping.Logic.Admin;
import com.onlineshopping.model.ProductCategory;
import com.onlineshopping.model.ProductStatus;
import com.onlineshopping.model.Product;

public class View {

	public static void main(String[] args) {
		Admin administrator= new Admin("ADMIN", "ADMIN", "ADMIN", "1234");
		
		administrator.addProduct("TV1", ProductStatus.AVAILABLE, ProductCategory.TV, "JUST A TV FOR TESTING", 1222.4, "LG", 5);
		administrator.addProduct("IPhone", ProductStatus.AVAILABLE, ProductCategory.PHONE, "JUST An Iphone FOR TESTING", 1200.0, "Apple", 10);
		administrator.addProduct("Laptop1", ProductStatus.AVAILABLE, ProductCategory.LAPTOP, "JUST A Laptop FOR TESTING", 500.0, "Sony", 4);
		administrator.addProduct("Beats", ProductStatus.AVAILABLE, ProductCategory.HEADPHONES, "JUST headphones FOR TESTING", 249.0, "Beats", 5);

		List<Product> products= new ArrayList<>();
		
		System.out.println("-------------------------------------view products--------------------------------------------------");
		products=administrator.viewProducts();
		
		for (Product product : products) {
			System.out.println(product);
		}
		
		products=administrator.searchProductsByCategory(ProductCategory.HEADPHONES);
		System.out.println("-------------------------------------search bu category--------------------------------------------------");
		for (Product product : products) {
			System.out.println(product);
		}
		System.out.println("-------------------------------------------------search by name--------------------------------------");
		Product product=administrator.findProductByName("TV1");
		System.out.println(product);
		
		System.out.println("-------------------------------------update product--------------------------------------------------");
	    product.setQuantity(100);
	    product.setStatus(ProductStatus.Recalled);
	    
	    administrator.updateProduct(product);
	    System.out.println("-------------------------------------removing a product--------------------------------------------------");
	    administrator.deleteProduct("Laptop1");
		
		administrator.closeConnection();
	}

}
