package com.onlineshopping.model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;

public class Cart {

	
	private List<OrderLine> orderLines;
	
	
	public Cart() {
		super();
		this.orderLines = new LinkedList<>();
	}

	public void addOrderLine(Product product, int quantity) {

		if(this.CheckProductAvailability(product, quantity))
			orderLines.add(new OrderLine(product,quantity));
		
	}

	public boolean CheckProductAvailability(Product mockProduct, int Quantity) {
	
	return false;
	}
	
	public void deleteOrderLine(OrderLine orderLine){
		orderLines.remove(orderLine);
	}

	public List<OrderLine> getOrderLines() {
		return orderLines;
	}

	

}
