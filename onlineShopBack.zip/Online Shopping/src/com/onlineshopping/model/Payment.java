package com.onlineshopping.model;

public class Payment {
private Card card;
private double totalAmount;


public Payment() {
	super();
	
}

public Payment(Card card) {
	super();
	this.card = card;
}

public Card getCard() {
	return card;
}

public void setCard(Card card) {
	this.card = card;
}

public double getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(double totalAmount) {
	this.totalAmount = totalAmount;
}



}
