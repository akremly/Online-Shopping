package com.onlineshopping.model;

import com.onlineshopping.Logic.LoginController;

public class RegisteredCustomer extends User{

	private LoginController loginController;
	private Account account;
	private Cart cart;
	private boolean LogedIn;
	
	
	

	public RegisteredCustomer() {
		super();
		this.cart=new Cart();
	}


	public RegisteredCustomer(LoginController loginController, Account account, Cart cart) {
		super();
		this.loginController = loginController;
		this.account = account;
		this.cart = cart;
	}


	public void LogIn(){
		this.loginController.LogIn();	
	}


	public void LogOut() {
		if(LogedIn)
		this.loginController.LogOut();	
		else
	   		 System.out.println("you have to Log-in first");
	}


	public void addProductToCart(Product p, int q) {
		if(LogedIn)
		this.cart.addOrderLine(p ,q );
		else
   		 System.out.println("you have to Log-in first");
	}

     public void deleteProductFromCart(OrderLine orderLine) {
    	 if(LogedIn)
		 this.cart.deleteOrderLine(orderLine);
    	 else
    		 System.out.println("you have to Log-in first");
    	}
     
     public void deleteCard(Card card){
    	 if(LogedIn)
    	 this.account.deleteCard(card);
    	 else
    		 System.out.println("you have to Log-in first");
     }
     
     public void AddCard(Card card){
    	 if(LogedIn)
    	this.account.addCard(card);
    	 else
    		 System.out.println("you have to Log-in first"); 
     }
	
}
