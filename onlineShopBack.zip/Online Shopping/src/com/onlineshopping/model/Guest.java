package com.onlineshopping.model;

public class Guest extends User {

	public Guest() {
		super();
	}

	
	
}
