package com.onlineshopping.model;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="TBL_ACCOUNT")
public class Account {
	@Id
	@Column(name="ACCOUNT_ID")
 	@SequenceGenerator(name="account_seq", sequenceName="Product_Sequence")
 	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="account_seq")
    private int Id;
	@Column(nullable=false, length=40)
    private String username;
	@Column(nullable=false, length=50)
    private String Password;
	@Column(nullable=false, length=50)
    private String email;
	@Column(name="START_DATE")
	@Temporal(TemporalType.DATE)
    private Date startDate;
	@Column(name="ACCOUNT_STATUS")
    private AccountStatus status;
	@Column(name="SHIPPING_ADDRESS")
    private String shippingAddress;
	@Column(name="HOME_ADDRESS")
    private String homeAddress;
	@OneToMany(mappedBy="account")
    private List<Card> cards;
	@OneToMany(mappedBy="account")
    private List<Order> orders;

public Account(String username, String password, String email, Date startDate, AccountStatus status,
		String shippingAddress, String homeAddress) {
	super();
	this.username = username;
	Password = password;
	this.email = email;
	this.startDate = startDate;
	this.status = status;
	this.shippingAddress = shippingAddress;
	this.homeAddress = homeAddress;
	this.cards = new LinkedList<>();
	this.orders= new LinkedList<>();
}

public int getId() {
	return Id;
}

public void setId(int id) {
	Id = id;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return Password;
}

public void setPassword(String password) {
	Password = password;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public Date getStartDate() {
	return startDate;
}

public void setStartDate(Date startDate) {
	this.startDate = startDate;
}

public AccountStatus getStatus() {
	return status;
}

public void setStatus(AccountStatus status) {
	this.status = status;
}

public String getShippingAddress() {
	return shippingAddress;
}

public void setShippingAddress(String shippingAddress) {
	this.shippingAddress = shippingAddress;
}

public String getHomeAddress() {
	return homeAddress;
}

public void setHomeAddress(String homeAddress) {
	this.homeAddress = homeAddress;
}

public List<Card> getCards() {
	return cards;
}


public List<Order> getOrders() {
	return orders;
}

public void addCard(Card card){
	cards.add(card);
}
public void deleteCard(Card card){
	cards.remove(card);
}

}
