package com.onlineshopping.Logic;

import java.util.List;

import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductCategory;
import com.onlineshopping.model.ProductStatus;

public class Admin implements InventoryUpdater {
private int Id;
private String firstName;
private String lastName;
private String userName;
private String password;
InventoryUpdater inventoryUpdater;
public Admin(String firstName, String lastName, String userName, String password) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.userName = userName;
	this.password = password;
	this.inventoryUpdater= new InventoryManager();
}
@Override
public void updateProduct(Product product) {
	this.inventoryUpdater.updateProduct(product);
}
@Override
public void addProduct(String name, ProductStatus status,ProductCategory category, String description, double price, String provider,
		int quantity) {

	this.inventoryUpdater.addProduct(name, status,category, description, price, provider, quantity);
}
@Override
public void deleteProduct(String name) {

	this.inventoryUpdater.deleteProduct(name);
}
@Override
public List<Product> viewProducts() {

	return this.inventoryUpdater.viewProducts();
}
@Override
public Product findProductByName(String name) {
	
	return this.inventoryUpdater.findProductByName(name);
}
@Override
public List<Product> searchProductsByCategory(ProductCategory category) {

	return this.inventoryUpdater.searchProductsByCategory(category);
}
@Override
public void closeConnection() {
	this.inventoryUpdater.closeConnection();
	
}






}
