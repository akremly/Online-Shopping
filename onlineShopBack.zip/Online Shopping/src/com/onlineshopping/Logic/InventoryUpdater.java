package com.onlineshopping.Logic;

import java.util.List;

import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductCategory;
import com.onlineshopping.model.ProductStatus;

public interface InventoryUpdater {
	 void updateProduct(Product product);
	 void addProduct(String name, ProductStatus status,ProductCategory category ,String description, double price, String provider, int quantity);
	 void deleteProduct(String name);
	 List<Product> viewProducts();
	 Product findProductByName(String name);
	 List<Product> searchProductsByCategory(ProductCategory category);
	 void closeConnection();
}
