package com.onlineshopping.Logic;

import com.onlineshopping.model.Account;

public class LoginController {

	
	
	public Account LogIn() {
		
		return null;
	}

	public void LogOut() {
	
		
	}

}
