package com.onlineshopping.Logic;

public interface AccountManagement {

	boolean CreatAccount();
}
