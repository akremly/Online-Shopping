package com.onlineshopping.Logic;

public class AccountManager implements AccountManagement {

	@Override
	public boolean CreatAccount() {
	
		return false;
	}

}
