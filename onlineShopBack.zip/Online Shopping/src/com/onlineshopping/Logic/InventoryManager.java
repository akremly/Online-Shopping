package com.onlineshopping.Logic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductCategory;
import com.onlineshopping.model.ProductStatus;

public class InventoryManager implements InventoryViewer, InventoryUpdater{

	private EntityManagerFactory emf=null;
	private EntityManager em=null;
	private EntityTransaction transaction=null;
	
	public InventoryManager() {
		super();
		this.emf=Persistence.createEntityManagerFactory("Online Shopping");
		this.em= emf.createEntityManager();
		this.transaction=em.getTransaction();
	}

	@Override
	public List<Product> viewProducts() {
	  Query query= em.createQuery("SELECT  p FROM Product p",Product.class);
		return query.getResultList();
	}

	@Override
	public List<Product> searchProductsByCategory(ProductCategory category) {
		  Query query= em.createQuery("SELECT  p FROM Product p WHERE p.category=:pcategory ",Product.class);
		  query.setParameter("pcategory", category);
		return query.getResultList();
	}

	@Override
	public void updateProduct(Product product) {
		Query query= em.createQuery("SELECT  p FROM Product p WHERE p.name=:pname ",Product.class);
		  query.setParameter("pname", product.getName());
		  Product Exproduct=(Product)query.getSingleResult();
		  transaction.begin();
		  Exproduct.setPrice(product.getPrice());
		  Exproduct.setDescription(product.getDescription());
		  Exproduct.setQuantity(product.getQuantity());
		  Exproduct.setStatus(product.getStatus());
		  Exproduct.setName(product.getName());
		  Exproduct.setProvider(product.getProvider());
		  transaction.commit();
		  em.clear();
	
		
	}

	@Override
	public void addProduct(String name, ProductStatus status,ProductCategory category ,String description, double price, String provider, int quantity) {
		Product product= new Product(name, status,category, description, price, provider, quantity);
		
		
		transaction.begin();
		em.persist(product);
		transaction.commit();
		em.clear();
	}

	@Override
	public void deleteProduct(String name) {
	Product product=this.findProductByName(name);
	transaction.begin();
	em.remove(product);
	transaction.commit();
	em.clear();
	}

	@Override
	public Product findProductByName(String name) {
		Query query= em.createQuery("SELECT  p FROM Product p WHERE p.name=:pname ",Product.class);
		  query.setParameter("pname", name);
		return (Product)query.getSingleResult();
	}
	
	public void closeConnection(){
		this.em.close();
	}

}
