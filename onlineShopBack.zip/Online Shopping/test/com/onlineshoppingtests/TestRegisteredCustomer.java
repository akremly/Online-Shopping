package com.onlineshoppingtests;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.onlineshopping.model.Account;
import com.onlineshopping.model.Cart;
import com.onlineshopping.Logic.LoginController;
import com.onlineshopping.model.Product;
import com.onlineshopping.model.RegisteredCustomer;

public class TestRegisteredCustomer {

	@Mock
	private static LoginController mockLoginController;
	@Mock
	private static Account mockAccount;
	@Mock
	private static Cart mockCart;
	@Mock
	private static Product mockProduct;
	
	
	private RegisteredCustomer customer= new RegisteredCustomer(mockLoginController,mockAccount,mockCart);
	
	@BeforeClass
	public static void setup(){
		TestRegisteredCustomer rct= new TestRegisteredCustomer();
		MockitoAnnotations.initMocks(rct);
	}
	
@Test
public void TestLoginByCustomerCallsLoginFromLoginControllerONEtIME(){
	customer.LogIn();
	verify(mockLoginController,times(1)).LogIn();
}


@Test
public void TestLogOutByCustomerCallsLogOutFromLoginControllerONEtIME(){
	customer.LogOut();
	verify(mockLoginController,times(1)).LogOut();
}

@Test
public void TestWhenCustomerAddProductToCartTheAddOrderLineFromCartIsCalledONEtIME(){
	customer.addProductToCart(anyObject(),anyInt());
	verify(mockCart,times(1)).addOrderLine(anyObject(), anyInt());
}

}
