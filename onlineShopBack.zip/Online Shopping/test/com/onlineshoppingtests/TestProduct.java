package com.onlineshoppingtests;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;

import com.onlineshopping.model.Product;
import com.onlineshopping.model.ProductStatus;

public class TestProduct {
	
private static Product product1;
private static Product product2;
private static Product product3;
private static ProductStatus status;

@BeforeClass
public static void setup(){

	product1= new Product("TV", status.AVAILABLE, "42 inch screan", 450.99, "LG",3);
	product2= new Product("TV",status.AVAILABLE, "42 inch screan", 450.99, "LG",3);
	product3= new Product("TV",status.AVAILABLE, "42 inch screan", 800.99, "Samsung",3);
}


@Test
public void testTwoProductsAreEqual(){
assertTrue(product1.equals(product2));
}

@Test
public void testTwoProductsAreNotEqual(){
	assertFalse(product1.equals(product3));
}
}
